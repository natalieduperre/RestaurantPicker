import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RestaurantSelector {
    public static void main(String[] args) {
        List<String> restaurants = new ArrayList<>();

        restaurants.add("Oxleys Sandwhich");
        restaurants.add("Connecting Grounds Acai Bowl");
        restaurants.add("Courtside Pasta");
        restaurants.add("Sloopys");
        restaurants.add("Ninja Grill");
        restaurants.add("Scott Dining Hall");
        restaurants.add("Chipotle");
        restaurants.add("ChickFilA");

        Collections.shuffle(restaurants);
        String chosenRestaurant = chooseRestaurant(restaurants);

        System.out.println("Eat at: " + chosenRestaurant);
    }

    private static String chooseRestaurant(List<String> restaurants) {
        return restaurants.get(0);
    }
}